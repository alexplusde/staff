<?php

rex_config::removeNamespace("staff");
