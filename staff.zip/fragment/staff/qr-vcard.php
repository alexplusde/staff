BEGIN:VCARD
VERSION:2.1
FN: %firstname% %lastname%
N:%lastname%;%firstname%
TITLE:%title%
TEL;CELL: %tel-cell%
TEL;WORK;VOICE:%tel-work%
TEL;HOME;VOICE:%tel-home%
EMAIL;HOME;INTERNET:%email-home%
EMAIL;WORK;INTERNET:%email-work%
URL:%url%
ADR:;;%street%;%city%;;%zip%;%country%
ORG:%company%
END:VCARD