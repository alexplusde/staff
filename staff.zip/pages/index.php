<?php

echo rex_view::title($this->getProperty('page')['title']);
rex_be_controller::includeCurrentPageSubPath();
